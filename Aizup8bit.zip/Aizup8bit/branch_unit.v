module branch_unit(
    input [3:0] opcode,
    input zero_flag,
    input [7:0] pc,
    input [7:0] imm8,
    output reg branch_taken,
    output [7:0] target
);
   
    assign target = pc + {{6{imm8[1]}}, imm8[1:0]};

    always @(*) begin
        case(opcode)
            4'hD: branch_taken = zero_flag;   // BZ
            4'hE: branch_taken = ~zero_flag;  // BNZ
            4'hF: branch_taken = 1'b1;        // BRA
            default: branch_taken = 1'b0;
        endcase
    end

endmodule