module forwarding_unit(
    input [1:0] ex_rs,
    input [1:0] ex_rt,
    input [1:0] mem_rd,
    input [1:0] wb_rd,
    input       mem_regwrite,
    input       wb_regwrite,
    output reg [1:0] fwd_a,
    output reg [1:0] fwd_b
);

    always @(*) begin
        fwd_a = 2'b00;
        fwd_b = 2'b00;

        if (mem_regwrite && (mem_rd != 0) && (mem_rd == ex_rs))
            fwd_a = 2'b10;
        else if (wb_regwrite && (wb_rd != 0) && (wb_rd == ex_rs))
            fwd_a = 2'b01;

        if (mem_regwrite && (mem_rd != 0) && (mem_rd == ex_rt))
            fwd_b = 2'b10;
        else if (wb_regwrite && (wb_rd != 0) && (wb_rd == ex_rt))
            fwd_b = 2'b01;
    end

endmodule