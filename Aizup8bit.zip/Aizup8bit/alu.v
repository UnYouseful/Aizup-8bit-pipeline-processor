module alu(
    input [7:0] a, b,
    input [2:0] op,
    output reg [7:0] y
);
    always @(*) begin
        case(op)
            3'd0: y = a + b;      // ADD / ADDI
            3'd1: y = a - b;      // SUB / SUBI
            3'd2: y = a | b;      // OR / SR0L
            3'd3: y = a & b;      // AND
            3'd4: y = a ^ b;      // XOR
            3'd5: y = b;          // MOV / SR0H
            default: y = 8'd0;
        endcase
    end

endmodule