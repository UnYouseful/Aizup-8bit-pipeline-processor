module program_counter(
    input clk,
    input reset,
    input branch_taken,
    input [7:0] branch_target,
    output reg [7:0] pc_out
);
    always @(posedge clk or posedge reset) begin
        if (reset)
            pc_out <= 8'd0;
        else if (branch_taken)
            pc_out <= branch_target;
        else
            pc_out <= pc_out + 1;
    end
endmodule