module control_unit(
    input [3:0] opcode,
    output reg [2:0] aop,
    output reg imm_sel,
    output reg reg_write,
    output reg mem_load,
    output reg mem_store,
    output reg zero_write
);

    always @(*) begin
        aop        = 3'd0;
        imm_sel    = 1'b0;
        reg_write  = 1'b0;
        mem_load   = 1'b0;
        mem_store  = 1'b0;
        zero_write = 1'b0;
        case(opcode)
            4'h0: begin // NOP
            
            end
            4'h1: begin // ADD
                  aop=3'd0; 
                  reg_write=1; 
                  zero_write=1; 
            end 
            4'h2: begin // SUB
                  aop=3'd1; 
                  reg_write=1; 
                  zero_write=1; 
            end
            4'h3: begin // OR
                  aop=3'd2; 
                  reg_write=1; 
                  zero_write=1; 
            end
            4'h4: begin // AND
                  aop=3'd3; 
                  reg_write=1; 
                  zero_write=1; 
            end
            4'h5: begin // XOR 
                  aop=3'd4; 
                  reg_write=1; 
                  zero_write=1; 
            end
            4'h6: begin // MOV
                  aop=3'd5; 
                  reg_write=1; 
                  zero_write=1; 
            end
            4'h7: begin // Load
                  mem_load=1; 
                  reg_write=1; 
            end
            4'h8: begin // ST 
                  mem_store=1; 
            end
            4'h9: begin // ADDI
                  aop=3'd0; 
                  imm_sel=1; 
                  reg_write=1; 
                  zero_write=1; 
            end
            4'hA: begin // SUBI
                  aop=3'd1; 
                  imm_sel=1; 
                  reg_write=1; 
                  zero_write=1; 
            end
            4'hB: begin // SR0L
                  aop=3'd2; 
                  imm_sel=1; 
                  reg_write=1; 
                  zero_write=1; 
            end
            4'hC: begin // SR0H 
                  aop=3'd5; 
                  imm_sel=1; 
                  reg_write=1; 
                  zero_write=1; 
            end
            default: begin
                  aop = 3'd0;
                  imm_sel    = 1'b0;
                  reg_write  = 1'b0;
                  mem_load   = 1'b0;
                  mem_store  = 1'b0;
                  zero_write = 1'b0;
            end
        endcase
    end

endmodule