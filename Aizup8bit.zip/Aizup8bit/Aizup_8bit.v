module Aizup_8bit(
    input clk,
    input reset,
    output [7:0] dbg_pc,
    output dbg_zero
);
    // IF Stage
    wire [7:0] pc_if, ir_if;
    wire br_if; wire [7:0] tgt_if;

    // program counter
    program_counter PC(
        .clk(clk),
        .reset(reset),
        .branch_taken(br_if),
        .branch_target(tgt_if),
        .pc_out(pc_if)
    );

    // instruction memory
    instruction_memory IM(
        .addr(pc_if), 
        .instr(ir_if)
    );

    // IF/ID
    reg [7:0] IF_ID_pc, IF_ID_ir;
    always @(posedge clk or posedge reset) begin
        if(reset) begin
            {IF_ID_pc,IF_ID_ir}<=0; 
        end
        else begin
            {IF_ID_pc,IF_ID_ir}<={pc_if, ir_if};
        end
    end

    // ID Stage
    wire [3:0] op_id  = IF_ID_ir[7:4];
    wire [1:0] rd_id  = IF_ID_ir[3:2];
    wire [1:0] rs_id  = IF_ID_ir[1:0];
    wire [7:0] imm_id = IF_ID_ir;

    // control unit
    wire [2:0] cu_aop; 
    wire cu_imm; 
    wire cu_we, cu_ld, cu_st, cu_zw;
    control_unit CU(
        .opcode(op_id),
        .aop(cu_aop),
        .imm_sel(cu_imm),
        .reg_write(cu_we),
        .mem_load(cu_ld),
        .mem_store(cu_st),
        .zero_write(cu_zw)
    );

    // branch unit
    wire br_id; 
    wire [7:0] tgt_id;
    branch_unit BU(
        .opcode(op_id),
        .zero_flag(dbg_zero),
        .pc(IF_ID_pc),
        .imm8(imm_id),
        .branch_taken(br_id),
        .target(tgt_id)
    );

    // Register file
    wire [7:0] rd1_id, rd2_id;
    register_file RF(
        .clk(clk),
        .we(wb_we),
        .ra1(rs_id),
        .ra2(rd_id),
        .wa(wb_rd),
        .wd(wb_data),
        .rd1(rd1_id),
        .rd2(rd2_id)
    );

    // ID/EX
    reg [7:0] ID_EX_pc, ID_EX_a, ID_EX_b, ID_EX_imm;
    reg [1:0] ID_EX_rd; 
    reg [2:0] ID_EX_aop; 
    reg ID_EX_we, ID_EX_ld, ID_EX_st, ID_EX_zw;

    always @(posedge clk or posedge reset) begin
        if(reset) begin
            {ID_EX_pc,ID_EX_a,ID_EX_b,ID_EX_imm,ID_EX_rd,ID_EX_aop,ID_EX_imm,ID_EX_we,ID_EX_ld,ID_EX_st,ID_EX_zw}<=0;
        end
        else begin
            ID_EX_pc    <= IF_ID_pc;
            ID_EX_a     <= rd1_id;
            ID_EX_b     <= rd2_id;
            ID_EX_imm   <= imm_id;
            ID_EX_rd    <= rd_id;
            ID_EX_aop   <= cu_aop;
            ID_EX_imm   <= cu_imm;
            ID_EX_we    <= cu_we;
            ID_EX_ld    <= cu_ld;
            ID_EX_st    <= cu_st;
            ID_EX_zw    <= cu_zw;
        end
    end

    reg [7:0] EX_MEM_alu, EX_MEM_b; 
    reg [1:0] EX_MEM_rd; 
    reg EX_MEM_we, EX_MEM_ld, EX_MEM_st, EX_MEM_zw;
    reg [7:0] MEM_WB_alu, MEM_WB_mem; 
    reg [1:0] MEM_WB_rd; 
    reg MEM_WB_we, MEM_WB_ld, MEM_WB_zw;

    // Forwarding Unit 
    wire [1:0] fwd_a, fwd_b;
    wire [7:0] alu_src_a, alu_src_b;

    forwarding_unit FU(
        .ex_rs(ID_EX_rd),
        .ex_rt(ID_EX_rd),
        .mem_rd(EX_MEM_rd),
        .wb_rd(MEM_WB_rd),
        .mem_regwrite(EX_MEM_we),
        .wb_regwrite(MEM_WB_we),
        .fwd_a(fwd_a),
        .fwd_b(fwd_b)
    );

    assign alu_src_a = (fwd_a == 2'b00) ? ID_EX_a :
                       (fwd_a == 2'b01) ? wb_data : EX_MEM_alu;

    wire [7:0] ex_b = ID_EX_imm ? ID_EX_imm : ID_EX_b;
    assign alu_src_b = (fwd_b == 2'b00) ? ex_b :
                       (fwd_b == 2'b01) ? wb_data : EX_MEM_alu;

    // EX Stage
    wire [7:0] alu_res;

    alu ALU(
        .a(alu_src_a),
        .b(alu_src_b),
        .op(ID_EX_aop),
        .y(alu_res)
    );

    wire br_ex = br_id; 
    wire [7:0] tgt_ex = tgt_id;

    // EX/MEM
    always @(posedge clk or posedge reset) begin
        if(reset) begin
            {EX_MEM_alu,EX_MEM_b,EX_MEM_rd,EX_MEM_we,EX_MEM_ld,EX_MEM_st,EX_MEM_zw}<=0;
        end
        else begin 
            EX_MEM_alu<=alu_res; 
            EX_MEM_b<=ID_EX_b; 
            EX_MEM_rd<=ID_EX_rd; 
            EX_MEM_we<=ID_EX_we; 
            EX_MEM_ld<=ID_EX_ld; 
            EX_MEM_st<=ID_EX_st; 
            EX_MEM_zw<=ID_EX_zw; 
        end
    end

    // MEM Stage
    wire [7:0] mem_out;
    data_memory DM(
        .clk(clk),
        .we(EX_MEM_st),
        .addr(EX_MEM_alu),
        .wdata(EX_MEM_b),
        .rdata(mem_out)
    );

    // MEM/WB
    always @(posedge clk or posedge reset) begin 
        if(reset) begin
            {MEM_WB_alu,MEM_WB_mem,MEM_WB_rd,MEM_WB_we,MEM_WB_ld,MEM_WB_zw}<=0;
        end
        else begin 
            MEM_WB_alu<=EX_MEM_alu; 
            MEM_WB_mem<=mem_out; 
            MEM_WB_rd<=EX_MEM_rd; 
            MEM_WB_we<=EX_MEM_we; 
            MEM_WB_ld<=EX_MEM_ld; 
            MEM_WB_zw<=EX_MEM_zw; 
        end
    end

    // WB Stage
    assign wb_data = MEM_WB_ld ? MEM_WB_mem : MEM_WB_alu;
    assign wb_rd   = MEM_WB_rd;
    assign wb_we   = MEM_WB_we;
    assign dbg_pc  = pc_if;
    assign dbg_zero= MEM_WB_zw && (wb_data==8'd0);
    assign br_if   = br_ex;
    assign tgt_if  = tgt_ex;

endmodule
