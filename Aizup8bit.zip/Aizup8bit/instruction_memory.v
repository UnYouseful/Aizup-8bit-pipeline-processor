module instruction_memory(
    input [7:0] addr,
    output [7:0] instr
);
    reg [7:0] mem [0:255];
    /* initial begin
        $readmemh("instr_mem.mem", mem);
    end */

    assign instr = mem[addr];

endmodule