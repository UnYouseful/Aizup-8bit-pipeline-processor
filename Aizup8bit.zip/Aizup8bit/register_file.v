module register_file(
    input clk,
    input we,
    input [1:0] ra1, ra2, wa,
    input [7:0] wd,
    output [7:0] rd1, rd2
);
    reg [7:0] rf [0:3];
    integer i; 
    initial begin 
        for(i=0;i<4;i=i+1) begin
            rf[i]=8'd0;
        end
    end

    always @(posedge clk) begin
        if (we) begin
            rf[wa] <= wd;
        end
    end

    assign rd1 = rf[ra1];
    assign rd2 = rf[ra2];
endmodule