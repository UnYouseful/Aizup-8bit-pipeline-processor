`timescale 1ns/1ps

module tb_Aizup_8bit;

    // Inputs
    reg clk;
    reg reset;

    // Debug outputs
    wire [7:0] dbg_pc;
    wire dbg_zero;

    // Instantiation
    Aizup_8bit dut (
        .clk(clk),
        .reset(reset),
        .dbg_pc(dbg_pc),
        .dbg_zero(dbg_zero)
    );

    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    initial begin
        $readmemh("instr_mem.mem", dut.IM.mem);
        $readmemh("data_mem.mem", dut.DM.mem);
    end

    initial begin
        reset = 1;
        #20;
        reset = 0;
        #500;

        // Display final register file and memory
        $display("\nSimulation complete. PC=%h, Zero=%b", dbg_pc, dbg_zero);
        $display("R0=%h R1=%h R2=%h R3=%h", dut.RF.rf[0], dut.RF.rf[1], dut.RF.rf[2], dut.RF.rf[3]);
        $stop;
    end

endmodule